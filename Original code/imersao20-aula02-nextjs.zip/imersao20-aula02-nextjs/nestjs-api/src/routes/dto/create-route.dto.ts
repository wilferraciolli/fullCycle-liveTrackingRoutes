export class CreateRouteDto {
  name: string;
  source_id: string;
  destination_id: string;
}
//dto - data transfer object
