# Imersão Fullcycle 20 - Sistema de rastreamento de veículos

## Descrição

Repositório do Golang (simulador dos trajetos e cálculo de frete).

## Requerimentos

Instale o Golang na sua máquina seguindo as instruções da aula ou siga este tutorial [https://go.dev/doc/install](https://go.dev/doc/install)

## Rodar a aplicação

Rode o comando:

```
go run cmd/simulator/main.go
```
